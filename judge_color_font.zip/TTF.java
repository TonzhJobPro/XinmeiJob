import java.io.*;

public class TTF
{
    /**
     * read tables from .ttf file
     */
    public static void main(String[] args)
    {

        System.out.println("=== Test Begin ===");

        String ttfPath;

        if (args.length > 0)
        {
            ttfPath = args[0];
        }
        else
        {
            ttfPath = "./water-melon-color.ttf";
        }
        TTF ttf = new TTF(ttfPath);
        String msg = ttf.isColorFont() ? "" : "not ";
        System.out.println(ttfPath + " is " + msg + "color font");

        System.out.println(" Done!");
    }

    protected String fontPath;
    protected FileInputStream in = null;

    // public TTF() {
    // 	fontPath = null;
    // }

    public TTF(String pathName)
    {
        fontPath = pathName;
    }

    boolean isColorFont()
    {
        try
        {
            if (fontPath == null || fontPath.equals(""))
            {
                return false;
            }

            // File ttfile = new File(fontPath);
            // long len = ttfile.length;
            in = new FileInputStream(fontPath);

            int sfnt_len = 12;
            byte[] sfnt = new byte[(int)sfnt_len];
            int len = 0;

            if ((len = in.read(sfnt)) < sfnt_len)
            {
                return false;
            }

            int table_num = byteArrayToShort(sfnt, 4);

            System.out.println("sfnt tables num:" + table_num);

            int entry_len = 16;

            byte[] entry = new byte[(int)entry_len];

            int cnt = 0;

            byte[] target = "CBDT".getBytes("ISO-8859-1");

            for (int i = 0; i < table_num; i++)
            {
                in.read(entry);

                // String tag = new String(subBytes(entry, 0, 4));
                // System.out.println("tag " + tag);
                // 
                // if (tag.equals(target)) {
                // 	return true;
                // }

                boolean tag_found = true;
                for (int j = target.length - 1; j >= 0 ; j--)   // search tag(entry's first 4 byte)
                {
                    if (target[j] != entry[j])
                    {
                        tag_found = false;
                        break;
                    }
                }

                if (tag_found)
                    return true;
            }


        }
        catch(Exception ex)
        {
        	// Simply return False on any exception (Sorry I am a freshman to java); 
        	// you may want to modify things here.
            System.out.println("Ignore exception:" + ex);
        }
        finally {
        	in.close();
        }
        return false;
    }

    public static int byteArrayToShort(byte[] b, int offset)
    {
        int value = 0;
        for (int i = 0; i < 2; i++)
        {
            int shift = (2 - 1 - i) * 8;
            value += (b[i + offset] & 0x000000FF) << shift;
        }
        return value;
    }

    // public static byte[] subBytes(byte[] src, int begin, int count) {
    //         byte[] bs = new byte[count];
    //         for (int i=begin; i<begin+count; i++) bs[i-begin] = src[i];
    //         return bs;
    // }
}